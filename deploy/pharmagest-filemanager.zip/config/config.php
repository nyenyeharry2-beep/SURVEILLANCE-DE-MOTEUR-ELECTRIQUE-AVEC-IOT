<?php
/**
 * Copiez ce fichier vers config.php et remplissez vos identifiants InfinityFree.
 * Dans le panneau InfinityFree : MySQL Databases → créez une base et un utilisateur.
 */

define('DB_HOST', 'sql211.infinityfree.com'); // Remplacez XXX par votre numéro de serveur
define('DB_NAME', 'if0_42810781_mapharmacieEve');      // Nom de la base de données
define('DB_USER', 'if0_42810781');             // Utilisateur MySQL
define('DB_PASS', 'z17M09vawZ5CwXr');       // Mot de passe MySQL
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'PharmaGest');
define('APP_URL', 'https://mapharmaciepk.xo.je'); // URL de votre site
define('TIMEZONE', 'Africa/Kinshasa'); // Fuseau horaire RDC

// 1 USD = X Francs Congolais (CDF)
define('TAUX_USD_CDF', 2850);

// Devise par défaut pour les prix des médicaments
define('DEVISE_DEFAUT', 'CDF');

date_default_timezone_set(TIMEZONE);
