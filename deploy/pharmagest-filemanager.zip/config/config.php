<?php
/**
 * Configuration PharmaGest — mapharmaciepk.xo.je
 * NE PAS versionner ce fichier (contient des identifiants).
 */

define('DB_HOST', 'sql211.infinityfree.com');
define('DB_NAME', 'if0_42810781_mapharmacieEve');
define('DB_USER', 'if0_42810781');
define('DB_PASS', 'z17M09vawZ5CwXr');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'Nouvelle Eve');
define('APP_TAGLINE', 'Votre santé, notre priorité');
define('APP_LOGO', 'assets/img/logo.jpg');
define('APP_URL', 'https://mapharmaciepk.xo.je');
define('APP_ADDRESS', 'Kinshasa, République Démocratique du Congo');
define('APP_PHONE', '+243 XXX XXX XXX');
define('TIMEZONE', 'Africa/Kinshasa');
define('TAUX_USD_CDF', 2850);
define('DEVISE_DEFAUT', 'CDF');
define('ALERTE_EXPIRATION_MOIS', 5);

date_default_timezone_set(TIMEZONE);
