<?php
define('DB_HOST', 'sql211.infinityfree.com');
define('DB_NAME', 'if0_42810781_mapharmacieEve');
define('DB_USER', 'if0_42810781');
define('DB_PASS', 'z17M09vawZ5CwXr');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME', 'PharmaGest');
define('APP_URL', 'https://mapharmaciepk.xo.je');
define('TIMEZONE', 'Africa/Abidjan');
date_default_timezone_set(TIMEZONE);
