<?php
define('DB_HOST', 'sql109.infinityfree.com');
define('DB_NAME', 'if0_42679313_KYRIOS');
define('DB_USER', 'if0_42679313');
define('DB_PASS', 'R9ePMkXcuwA76y');
define('JWT_SECRET', 'kyrios-infinityfree-secret-2026');
